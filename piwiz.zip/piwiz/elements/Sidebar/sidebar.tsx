import ellipse18 from "./ellipse-18.svg";
import line5 from "./line-5.svg";

type IconName =
  | "dashboard"
  | "courses"
  | "history"
  | "profile"
  | "settings"
  | "logout"
  | "help";

type NavigationItem = {
  label: string;
  icon: IconName;
  active?: boolean;
};

const primaryNavigation: NavigationItem[] = [
  { label: "Dashboard", icon: "dashboard", active: true },
  { label: "My Courses", icon: "courses" },
  { label: "Purchase History", icon: "history" },
];

const secondaryNavigation: NavigationItem[] = [
  { label: "Profile", icon: "profile" },
  { label: "Settings", icon: "settings" },
  { label: "Log out", icon: "logout" },
];

const Icon = ({
  name,
  className = "",
}: {
  name: IconName;
  className?: string;
}): JSX.Element => {
  const commonProps = {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className,
    "aria-hidden": true,
  };

  if (name === "dashboard") {
    return (
      <svg {...commonProps}>
        <rect
          x="3.5"
          y="3.5"
          width="7"
          height="7"
          rx="1.5"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <rect
          x="13.5"
          y="3.5"
          width="7"
          height="7"
          rx="1.5"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <rect
          x="3.5"
          y="13.5"
          width="7"
          height="7"
          rx="1.5"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <rect
          x="13.5"
          y="13.5"
          width="7"
          height="7"
          rx="1.5"
          stroke="currentColor"
          strokeWidth="1.8"
        />
      </svg>
    );
  }

  if (name === "courses") {
    return (
      <svg {...commonProps}>
        <rect
          x="4"
          y="2.8"
          width="16"
          height="18.4"
          rx="3"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <path
          d="M8 8H16M8 12H16M8 16H13"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
      </svg>
    );
  }

  if (name === "history") {
    return (
      <svg {...commonProps}>
        <path
          d="M4 10.5V8.8C4 7.25 5.25 6 6.8 6H17.2C18.75 6 20 7.25 20 8.8V16.2C20 17.75 18.75 19 17.2 19H6.8C5.25 19 4 17.75 4 16.2V14.5"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <path
          d="M4 10.5H9.5C10.33 10.5 11 11.17 11 12C11 12.83 10.33 13.5 9.5 13.5H4M15 9.5H17M15 13H17"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        <path
          d="M4 8L6.3 5.7M4 8L1.7 5.7"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
      </svg>
    );
  }

  if (name === "profile") {
    return (
      <svg {...commonProps}>
        <circle
          cx="12"
          cy="7.5"
          r="3.2"
          stroke="currentColor"
          strokeWidth="1.8"
        />
        <path
          d="M5 20C5.45 16.55 8.1 14.5 12 14.5C15.9 14.5 18.55 16.55 19 20"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
      </svg>
    );
  }

  if (name === "settings") {
    return (
      <svg {...commonProps}>
        <path
          d="M9.7 3.8L10.4 2.7H13.6L14.3 3.8L14.1 5.1C14.75 5.4 15.35 5.75 15.9 6.2L17.1 5.7L19.7 7.3L19.5 8.7L18.4 9.5C18.55 10.2 18.55 10.8 18.4 11.5L19.5 12.3L19.7 13.7L17.1 15.3L15.9 14.8C15.35 15.25 14.75 15.6 14.1 15.9L14.3 17.2L13.6 18.3H10.4L9.7 17.2L9.9 15.9C9.25 15.6 8.65 15.25 8.1 14.8L6.9 15.3L4.3 13.7L4.5 12.3L5.6 11.5C5.45 10.8 5.45 10.2 5.6 9.5L4.5 8.7L4.3 7.3L6.9 5.7L8.1 6.2C8.65 5.75 9.25 5.4 9.9 5.1L9.7 3.8Z"
          stroke="currentColor"
          strokeWidth="1.7"
          strokeLinejoin="round"
        />
        <circle
          cx="12"
          cy="10.5"
          r="2.3"
          stroke="currentColor"
          strokeWidth="1.7"
        />
      </svg>
    );
  }

  if (name === "logout") {
    return (
      <svg {...commonProps}>
        <path
          d="M14 5H8.5C7.12 5 6 6.12 6 7.5V16.5C6 17.88 7.12 19 8.5 19H14"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        <path
          d="M13 12H21M18 9L21 12L18 15"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  return (
    <svg {...commonProps}>
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8" />
      <path
        d="M12 16V16.1M10.5 9.5C10.5 8.67 11.17 8 12 8C12.83 8 13.5 8.67 13.5 9.5C13.5 10.7 12 10.8 12 12.1"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
};

const NavigationButton = ({
  item,
  onSelect,
}: {
  item: NavigationItem;
  onSelect: (label: string) => void;
}): JSX.Element => {
  return (
    <button
      type="button"
      aria-current={item.active ? "page" : undefined}
      onClick={() => onSelect(item.label)}
      className={`flex w-[164px] items-center gap-2.5 px-2.5 py-3 relative flex-[0_0_auto] bg-neutralwhite-pure text-left transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-primarypr-5 ${
        item.active ? "text-primarypr-5" : "text-neutralnt-6"
      }`}
    >
      <Icon name={item.icon} className="relative w-5 h-5 aspect-[1] shrink-0" />
      <span
        className={`relative flex-1 mt-[-3.00px] ${
          item.active
            ? "font-typogrphy-body-text-ts-semibold font-[number:var(--typogrphy-body-text-ts-semibold-font-weight)] text-primarypr-5 text-[length:var(--typogrphy-body-text-ts-semibold-font-size)] tracking-[var(--typogrphy-body-text-ts-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-ts-semibold-line-height)]"
            : "font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-ts-medium-font-size)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)]"
        } [font-style:var(--typogrphy-body-text-ts-medium-font-style)]`}
      >
        {item.label}
      </span>
    </button>
  );
};

export const Sidebar = (): JSX.Element => {
  const [selectedItem, setSelectedItem] = useState("Dashboard");
  const [helpRequested, setHelpRequested] = useState(false);

  const handleSelect = (label: string): void => {
    setSelectedItem(label);
  };

  return (
    <aside
      aria-label="Learner navigation"
      className="flex flex-col w-[203px] h-[890px] items-center justify-between p-5 relative bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2"
    >
      <div className="inline-flex flex-col items-start gap-4 relative flex-[0_0_auto] ml-[-0.50px] mr-[-0.50px]">
        <div className="flex flex-col items-center gap-2 relative self-stretch w-full flex-[0_0_auto]">
          <img
            className="relative w-[120px] h-[120px] aspect-[1] object-cover rounded-full"
            alt="Sheila Vania"
            src={ellipse18}
          />
          <div className="flex flex-col items-center justify-center relative self-stretch w-full flex-[0_0_auto]">
            <h1 className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tl-medium font-[number:var(--typogrphy-body-text-tl-medium-font-weight)] text-neutralnt-9 text-[length:var(--typogrphy-body-text-tl-medium-font-size)] text-center tracking-[var(--typogrphy-body-text-tl-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tl-medium-line-height)] [font-style:var(--typogrphy-body-text-tl-medium-font-style)]">
              Sheila Vania
            </h1>
            <p className="relative w-fit font-typogrphy-body-text-txs-medium font-[number:var(--typogrphy-body-text-txs-medium-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-txs-medium-font-size)] tracking-[var(--typogrphy-body-text-txs-medium-letter-spacing)] leading-[var(--typogrphy-body-text-txs-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-txs-medium-font-style)]">
              Learner
            </p>
          </div>
        </div>
        <nav
          aria-label="Account sections"
          className="inline-flex flex-col items-start gap-4 relative flex-[0_0_auto]"
        >
          <div className="inline-flex flex-col items-start relative flex-[0_0_auto]">
            {primaryNavigation.map((item) => (
              <NavigationButton
                key={item.label}
                item={{ ...item, active: selectedItem === item.label }}
                onSelect={handleSelect}
              />
            ))}
          </div>
          <img
            className="relative self-stretch w-full h-px object-cover"
            alt=""
            src={line5}
          />
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
            {secondaryNavigation.map((item) => (
              <NavigationButton
                key={item.label}
                item={{ ...item, active: selectedItem === item.label }}
                onSelect={handleSelect}
              />
            ))}
          </div>
        </nav>
      </div>
      <div className="flex flex-col items-center relative self-stretch w-full flex-[0_0_auto]">
        <button
          type="button"
          aria-label="Open help center"
          onClick={() => setHelpRequested(false)}
          className="inline-flex items-center justify-center gap-2.5 p-4 relative flex-[0_0_auto] z-[1] bg-accentredrd-5 rounded-[90px] text-neutralwhite-pure focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accentredrd-5"
        >
          <Icon name="help" className="relative w-6 h-6 aspect-[1]" />
        </button>
        <section
          aria-labelledby="help-center-title"
          className="flex flex-col items-center justify-center gap-2 pt-[46px] pb-9 px-[15px] relative self-stretch w-full flex-[0_0_auto] -mt-7 z-0 rounded-[20px] bg-[linear-gradient(0deg,rgba(42,49,60,1)_0%,rgba(42,49,60,1)_100%)]"
        >
          <h2
            id="help-center-title"
            className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tl-medium font-[number:var(--typogrphy-body-text-tl-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tl-medium-font-size)] text-center tracking-[var(--typogrphy-body-text-tl-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tl-medium-line-height)] [font-style:var(--typogrphy-body-text-tl-medium-font-style)]"
          >
            Help Center
          </h2>
          <p className="relative self-stretch font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-neutralnt-2 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] text-center tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] [font-style:var(--typogrphy-body-text-txs-regular-font-style)]">
            Got a problem?
            <br />
            Find answers here
          </p>
          <button
            type="button"
            onClick={() => setHelpRequested(true)}
            aria-live="polite"
            className="flex items-center justify-center gap-2.5 px-3 py-2 relative self-stretch w-full flex-[0_0_auto] bg-primarypr-5 rounded-xl text-neutralwhite-pure transition-colors hover:bg-primarypr-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primarypr-5"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] text-center tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              {helpRequested ? "Help Requested" : "Get Help"}
            </span>
          </button>
        </section>
      </div>
    </aside>
  );
};

export default Sidebar;