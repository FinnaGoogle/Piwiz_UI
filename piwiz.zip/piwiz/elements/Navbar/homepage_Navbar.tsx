import { useState } from "react";
import { CoursesDropdownIcon } from "./CoursesDropdownIcon";
import image from "./image.svg";
import { SignInIcon } from "./SignInIcon";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

const navigationItems = [
  { label: "Home", href: "#" },
  { label: "Event & Workshop", href: "#" },
  { label: "Blog", href: "#" },
  { label: "Career Guide", href: "#" },
];

const courseItems = [
  { label: "All courses", href: "#" },
  { label: "Popular courses", href: "#" },
  { label: "New courses", href: "#" },
];

export const Navbar = (): JSX.Element => {
  const [coursesOpen, setCoursesOpen] = useState(false);

  return (
    <header className="w-full">
      <nav
        aria-label="Main navigation"
        className="flex w-[1440px] items-center justify-between px-[60px] py-4 relative"
      >
        <a
          href="#"
          aria-label="CourseHub home"
          className="inline-flex items-center gap-2 relative flex-[0_0_auto]"
        >
          <span aria-hidden="true" className="relative w-[39.86px] h-10">
            <img
              className="absolute w-full h-full top-0 left-0"
              alt=""
              src={vector}
            />
            <img
              className="absolute w-[35.15%] h-[44.45%] top-[55.55%] left-[64.85%]"
              alt=""
              src={image}
            />
            <img
              className="absolute w-[44.48%] h-[34.91%] top-[65.09%] left-[55.52%]"
              alt=""
              src={vector2}
            />
            <img
              className="absolute w-[62.63%] h-[29.52%] top-[70.48%] left-[37.37%]"
              alt=""
              src={vector3}
            />
            <img
              className="absolute w-[84.61%] h-[35.08%] top-[64.92%] left-[15.39%]"
              alt=""
              src={vector4}
            />
            <img
              className="absolute w-[97.33%] h-[44.47%] top-[55.53%] left-[2.67%]"
              alt=""
              src={vector5}
            />
          </span>
          <span className="relative w-fit font-typogrphy-display-dxs-bold font-[number:var(--typogrphy-display-dxs-bold-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-display-dxs-bold-font-size)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] leading-[var(--typogrphy-display-dxs-bold-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
            CourseHub
          </span>
        </a>
        <div className="inline-flex items-center relative flex-[0_0_auto]">
          <a
            href="#"
            className="inline-flex items-center justify-center gap-2.5 p-2.5 relative flex-[0_0_auto]"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
              Home
            </span>
          </a>
          <div className="relative inline-flex items-center justify-center gap-2 p-2.5 flex-[0_0_auto]">
            <button
              type="button"
              aria-expanded={coursesOpen}
              aria-haspopup="menu"
              onClick={() => setCoursesOpen((open) => !open)}
              className="inline-flex items-center justify-center gap-2"
            >
              <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
                Courses
              </span>
              <CoursesDropdownIcon className="!relative !w-4 !h-4 !aspect-[1]" />
            </button>
            {coursesOpen && (
              <div
                role="menu"
                aria-label="Courses"
                className="absolute left-0 top-full z-10 mt-1 min-w-[150px] rounded-md bg-neutralwhite-pure p-2 shadow-card-shadow"
              >
                {courseItems.map((course) => (
                  <a
                    key={course.label}
                    href={course.href}
                    role="menuitem"
                    className="block rounded px-3 py-2 font-typogrphy-body-text-ts-regular text-neutralnt-10 hover:bg-neutralnt-1"
                    onClick={() => setCoursesOpen(false)}
                  >
                    {course.label}
                  </a>
                ))}
              </div>
            )}
          </div>
          {navigationItems.slice(1).map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="inline-flex items-center justify-center gap-2.5 p-2.5 relative flex-[0_0_auto]"
            >
              <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
                {item.label}
              </span>
            </a>
          ))}
        </div>
        <div className="inline-flex items-center relative flex-[0_0_auto]">
          <button
            type="button"
            className="flex w-[111px] items-center justify-center gap-2.5 px-3.5 py-3 relative bg-accentyellowyl-5 rounded-[30px]"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Sign in
            </span>
          </button>
          <button
            type="button"
            aria-label="Open sign in"
            className="flex w-12 h-12 items-center justify-center gap-2.5 p-3.5 relative -ml-0.5 bg-accentyellowyl-5 rounded-3xl"
          >
            <SignInIcon className="!relative !w-5 !h-5 !aspect-[1]" />
          </button>
        </div>
      </nav>
    </header>
  );