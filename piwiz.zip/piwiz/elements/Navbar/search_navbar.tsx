import { FormEvent, useState } from "react";
import { Frame } from "./Frame";
import { Frame1 } from "./Frame1";
import { IconComponentNode } from "./IconComponentNode";
import image from "./image.svg";
import line1 from "./line-1.svg";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

const navigationItems = [
  { label: "Home", active: true, hasDropdown: false },
  { label: "Courses", active: false, hasDropdown: true },
  { label: "Join Class", active: false, hasDropdown: true },
  { label: "Event & Workshop", active: false, hasDropdown: false },
  { label: "Career Guide", active: false, hasDropdown: false },
];

export const Component = (): JSX.Element => {
  const [searchQuery, setSearchQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmittedQuery(searchQuery.trim());
  };

  return (
    <main className="flex min-h-screen w-full min-w-[1024px] flex-col items-start relative bg-neutralwhite-pure">
      <header className="flex items-center justify-between px-[60px] py-4 relative self-stretch w-full flex-[0_0_auto] border-b [border-bottom-style:solid] border-neutralnt-2">
        <a
          href="/"
          aria-label="CourseHub home"
          className="inline-flex items-center gap-2 relative flex-[0_0_auto]"
        >
          <div className="relative w-[39.86px] h-10" aria-hidden="true">
            <img
              className="absolute w-full h-full top-0 left-0"
              alt=""
              src={vector}
            />
            <img
              className="absolute w-[35.15%] h-[44.45%] top-[55.55%] left-[64.85%]"
              alt=""
              src={image}
            />
            <img
              className="absolute w-[44.48%] h-[34.91%] top-[65.09%] left-[55.52%]"
              alt=""
              src={vector2}
            />
            <img
              className="absolute w-[62.63%] h-[29.52%] top-[70.48%] left-[37.37%]"
              alt=""
              src={vector3}
            />
            <img
              className="absolute w-[84.61%] h-[35.08%] top-[64.92%] left-[15.39%]"
              alt=""
              src={vector4}
            />
            <img
              className="absolute w-[97.33%] h-[44.47%] top-[55.53%] left-[2.67%]"
              alt=""
              src={vector5}
            />
          </div>
          <span className="relative w-fit font-typogrphy-display-dxs-bold font-[number:var(--typogrphy-display-dxs-bold-font-weight)] text-neutralnt-10 text-[length:var(--typogrphy-display-dxs-bold-font-size)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] leading-[var(--typogrphy-display-dxs-bold-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
            CourseHub
          </span>
        </a>
        <form
          onSubmit={handleSearch}
          role="search"
          aria-label="Course search"
          className="flex w-[588px] h-[60px] items-center justify-between p-3 relative bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-3"
        >
          <label htmlFor="course-search" className="sr-only">
            Search courses
          </label>
          <input
            id="course-search"
            name="courseSearch"
            type="search"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="Search any courses you want...."
            className="relative min-w-0 flex-1 font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] text-neutralnt-5 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] [font-style:var(--typogrphy-body-text-tm-regular-font-style)] placeholder:text-neutralnt-5"
          />
          <button
            type="submit"
            aria-label="Search courses"
            className="inline-flex items-center gap-3 px-3 py-2 relative flex-[0_0_auto] mt-[-2.00px] mb-[-2.00px] bg-primarypr-5 rounded-xl"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] text-neutralnt-1 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
              Search
            </span>
            <Frame className="!relative !w-4 !h-4 !aspect-[1]" />
          </button>
        </form>
        <div className="inline-flex items-center gap-3 relative flex-[0_0_auto]">
          <button
            type="button"
            className="all-unset box-border border border-solid border-primarypr-6 inline-flex items-center justify-center gap-2.5 p-3 relative flex-[0_0_auto] rounded-xl"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-primarypr-6 text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Register
            </span>
          </button>
          <button
            type="button"
            className="all-unset box-border bg-primarypr-5 inline-flex items-center justify-center gap-2.5 p-3 relative flex-[0_0_auto] rounded-xl"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Login
            </span>
          </button>
        </div>
      </header>
      <nav
        aria-label="Primary navigation"
        className="flex items-center gap-3 px-[60px] py-3 relative self-stretch w-full flex-[0_0_auto]"
      >
        <button
          type="button"
          aria-label="Open categories"
          className="inline-flex items-center gap-3 p-2.5 relative flex-[0_0_auto]"
        >
          <IconComponentNode className="!relative !w-5 !h-5 !aspect-[1]" />
          <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-neutralnt-9 text-[length:var(--typogrphy-body-text-ts-medium-font-size)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-medium-font-style)]">
            Categories
          </span>
        </button>
        <img
          className="relative w-px h-[26px] object-cover"
          alt=""
          aria-hidden="true"
          src={line1}
        />
        <div className="inline-flex items-center relative flex-[0_0_auto]">
          {navigationItems.map((item) => (
            <a
              key={item.label}
              href={`#${item.label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
              aria-current={item.active ? "page" : undefined}
              className={`inline-flex items-center justify-center ${
                item.hasDropdown ? "gap-2" : "gap-2.5"
              } p-2.5 relative flex-[0_0_auto]`}
            >
              <span
                className={`relative w-fit mt-[-1.00px] ${
                  item.active
                    ? "font-typogrphy-body-text-ts-semibold font-[number:var(--typogrphy-body-text-ts-semibold-font-weight)] text-neutralnt-9 text-[length:var(--typogrphy-body-text-ts-semibold-font-size)] tracking-[var(--typogrphy-body-text-ts-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-ts-semibold-line-height)] [font-style:var(--typogrphy-body-text-ts-semibold-font-style)]"
                    : "font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)]"
                } whitespace-nowrap`}
              >
                {item.label}
              </span>
              {item.hasDropdown && (
                <Frame1 className="!relative !w-4 !h-4 !aspect-[1]" />
              )}
            </a>
          ))}
        </div>
      </nav>
      {submittedQuery && (
        <p className="sr-only" role="status" aria-live="polite">
          Search submitted for {submittedQuery}.
        </p>
      )}
    </main>
  );
};