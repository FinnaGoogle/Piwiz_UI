import { FormEvent, useState } from "react";
import image from "./image.svg";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

type PasswordFieldProps = {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  visible: boolean;
  onToggleVisibility: () => void;
  describedBy?: string;
};

const PasswordField = ({
  id,
  label,
  value,
  onChange,
  visible,
  onToggleVisibility,
  describedBy,
}: PasswordFieldProps): JSX.Element => {
  return (
    <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
      <label
        htmlFor={id}
        className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
      >
        {label}
      </label>
      <div className="items-center justify-between p-3.5 bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 flex relative self-stretch w-full flex-[0_0_auto]">
        <input
          id={id}
          name={id}
          required
          minLength={8}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          type={visible ? "text" : "password"}
          placeholder="************"
          aria-describedby={describedBy}
          className="relative min-w-0 flex-1 mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-4 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)] placeholder:text-neutralnt-4"
        />
        <button
          type="button"
          onClick={onToggleVisibility}
          aria-label={
            visible
              ? `Hide ${label.toLowerCase()}`
              : `Show ${label.toLowerCase()}`
          }
          aria-pressed={visible}
          className="ml-3 flex h-4 w-4 shrink-0 items-center justify-center text-neutralnt-4"
        >
          <svg
            aria-hidden="true"
            className="h-4 w-4"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M1.333 8s2.4-4 6.667-4 6.667 4 6.667 4-2.4 4-6.667 4-6.667-4-6.667-4Z"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M8 10.167a2.167 2.167 0 1 0 0-4.334 2.167 2.167 0 0 0 0 4.334Z"
              stroke="currentColor"
              strokeWidth="1.5"
            />
          </svg>
        </button>
      </div>
    </div>
  );
};

export const LeftContainer = (): JSX.Element => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();

    if (password.length < 8 || confirmPassword.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setError("");
  };

  return (
    <main className="flex min-h-screen w-full items-start justify-center bg-neutralwhite-pure px-4 py-8 sm:py-[50px]">
      <section className="flex w-full max-w-[650px] flex-col items-center gap-[30px] rounded-3xl bg-neutralwhite-pure px-6 py-8 sm:px-[60px] sm:py-[50px]">
        <header className="flex flex-col items-start gap-5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex items-center gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative h-10 w-[39.86px]" aria-hidden="true">
              <img
                className="absolute left-0 top-0 h-full w-full"
                alt=""
                src={vector}
              />
              <img
                className="absolute left-[64.85%] top-[55.55%] h-[44.45%] w-[35.15%]"
                alt=""
                src={image}
              />
              <img
                className="absolute left-[55.52%] top-[65.09%] h-[34.91%] w-[44.48%]"
                alt=""
                src={vector2}
              />
              <img
                className="absolute left-[37.37%] top-[70.48%] h-[29.52%] w-[62.63%]"
                alt=""
                src={vector3}
              />
              <img
                className="absolute left-[15.39%] top-[64.92%] h-[35.08%] w-[84.61%]"
                alt=""
                src={vector4}
              />
              <img
                className="absolute left-[2.67%] top-[55.53%] h-[44.47%] w-[97.33%]"
                alt=""
                src={vector5}
              />
            </div>
            <div className="relative w-fit font-typogrphy-display-dxs-bold font-[number:var(--typogrphy-display-dxs-bold-font-weight)] text-neutralnt-10 text-[length:var(--typogrphy-display-dxs-bold-font-size)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] leading-[var(--typogrphy-display-dxs-bold-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
              CourseHub
            </div>
          </div>
          <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <h1 className="relative w-fit mt-[-1.00px] font-typogrphy-display-dl-regular font-[number:var(--typogrphy-display-dl-regular-font-weight)] text-neutralnt-10 text-[length:var(--typogrphy-display-dl-regular-font-size)] text-center tracking-[var(--typogrphy-display-dl-regular-letter-spacing)] leading-[var(--typogrphy-display-dl-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dl-regular-font-style)]">
              Set New Password
            </h1>
            <p className="relative self-stretch font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
              Create a fresh password to secure your account.
            </p>
          </div>
        </header>
        <form
          onSubmit={handleSubmit}
          noValidate={false}
          className="flex-col items-center gap-[22px] flex relative self-stretch w-full flex-[0_0_auto]"
        >
          <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <PasswordField
              id="password"
              label="Set New Password"
              value={password}
              onChange={setPassword}
              visible={passwordVisible}
              onToggleVisibility={() =>
                setPasswordVisible((current) => !current)
              }
              describedBy="password-requirements"
            />
            <div
              id="password-requirements"
              className="flex items-start gap-1.5 relative self-stretch w-full flex-[0_0_auto]"
            >
              <svg
                aria-hidden="true"
                className="relative mt-0.5 h-3.5 w-3.5 shrink-0 text-neutralnt-6"
                viewBox="0 0 14 14"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle
                  cx="7"
                  cy="7"
                  r="6"
                  stroke="currentColor"
                  strokeWidth="1.5"
                />
                <path
                  d="M7 6.25V9.25M7 4.5V4.75"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
              <p className="relative flex-1 mt-[-1.00px] font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] [font-style:var(--typogrphy-body-text-txs-regular-font-style)]">
                Use at least 8 characters with a mix of letters and numbers.
              </p>
            </div>
          </div>
          <PasswordField
            id="confirm-password"
            label="Confirm Password"
            value={confirmPassword}
            onChange={setConfirmPassword}
            visible={confirmPasswordVisible}
            onToggleVisibility={() =>
              setConfirmPasswordVisible((current) => !current)
            }
          />
          {error ? (
            <p
              role="alert"
              className="relative self-stretch font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-accentredrd-7 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] [font-style:var(--typogrphy-body-text-txs-regular-font-style)]"
            >
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            className="all-unset box-border flex items-center justify-center gap-2.5 rounded-xl bg-primarypr-5 p-3 relative self-stretch w-full flex-[0_0_auto] text-neutralwhite-pure transition-colors hover:bg-primarypr-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primarypr-6"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Submit
            </span>
          </button>
        </form>
      </section>
    </main>
  );
};

export default LeftContainer;