import { FormEvent, KeyboardEvent, useRef, useState } from "react";
import image from "./image.svg";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

const CODE_LENGTH = 5;
const initialCode = ["4", "0", "0", "0", "0"];

export const Container = (): JSX.Element => {
  const [code, setCode] = useState<string[]>(initialCode);
  const inputRefs = useRef<Array<HTMLInputElement | null>>([]);
  const [message, setMessage] = useState("");

  const focusInput = (index: number) => {
    inputRefs.current[index]?.focus();
  };

  const updateCode = (index: number, value: string) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    const nextCode = [...code];
    nextCode[index] = digit;
    setCode(nextCode);
    setMessage("");

    if (digit && index < CODE_LENGTH - 1) {
      focusInput(index + 1);
    }
  };

  const handleKeyDown = (
    event: KeyboardEvent<HTMLInputElement>,
    index: number,
  ) => {
    if (event.key === "Backspace" && !code[index] && index > 0) {
      const nextCode = [...code];
      nextCode[index - 1] = "";
      setCode(nextCode);
      focusInput(index - 1);
    }

    if (event.key === "ArrowLeft" && index > 0) {
      event.preventDefault();
      focusInput(index - 1);
    }

    if (event.key === "ArrowRight" && index < CODE_LENGTH - 1) {
      event.preventDefault();
      focusInput(index + 1);
    }
  };

  const handlePaste = (
    event: React.ClipboardEvent<HTMLInputElement>,
    index: number,
  ) => {
    event.preventDefault();

    const pastedDigits = event.clipboardData
      .getData("text")
      .replace(/\D/g, "")
      .slice(0, CODE_LENGTH - index);

    if (!pastedDigits) {
      return;
    }

    const nextCode = [...code];

    pastedDigits.split("").forEach((digit, offset) => {
      nextCode[index + offset] = digit;
    });

    setCode(nextCode);
    focusInput(Math.min(index + pastedDigits.length, CODE_LENGTH - 1));
    setMessage("");
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (code.some((digit) => !digit)) {
      setMessage("Please enter the complete code.");
      focusInput(code.findIndex((digit) => !digit));
      return;
    }

    setMessage("Code submitted.");
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-neutralwhite-pure">
      <form
        className="flex flex-col w-[650px] items-center gap-[30px] px-[60px] py-[50px] relative bg-neutralwhite-pure rounded-3xl"
        onSubmit={handleSubmit}
        noValidate
      >
        <div className="flex flex-col items-start gap-3 self-stretch w-full relative flex-[0_0_auto]">
          <div className="flex items-center gap-2 self-stretch w-full relative flex-[0_0_auto]">
            <div
              className="relative w-[39.86px] h-10"
              aria-label="CourseHub logo"
            >
              <img
                className="absolute w-full h-full top-0 left-0"
                alt=""
                src={vector}
              />
              <img
                className="absolute w-[35.15%] h-[44.45%] top-[55.55%] left-[64.85%]"
                alt=""
                src={image}
              />
              <img
                className="absolute w-[44.48%] h-[34.91%] top-[65.09%] left-[55.52%]"
                alt=""
                src={vector2}
              />
              <img
                className="absolute w-[62.63%] h-[29.52%] top-[70.48%] left-[37.37%]"
                alt=""
                src={vector3}
              />
              <img
                className="absolute w-[84.61%] h-[35.08%] top-[64.92%] left-[15.39%]"
                alt=""
                src={vector4}
              />
              <img
                className="absolute w-[97.33%] h-[44.47%] top-[55.53%] left-[2.67%]"
                alt=""
                src={vector5}
              />
            </div>
            <div className="relative w-fit font-typogrphy-display-dxs-bold font-[number:var(--typogrphy-display-dxs-bold-font-weight)] text-neutralnt-10 text-[length:var(--typogrphy-display-dxs-bold-font-size)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] leading-[var(--typogrphy-display-dxs-bold-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
              CourseHub
            </div>
          </div>
          <div className="inline-flex flex-col items-start gap-2 relative flex-[0_0_auto]">
            <h1 className="relative w-fit mt-[-1.00px] font-typogrphy-display-dl-regular font-[number:var(--typogrphy-display-dl-regular-font-weight)] text-neutralnt-10 text-[length:var(--typogrphy-display-dl-regular-font-size)] tracking-[var(--typogrphy-display-dl-regular-letter-spacing)] leading-[var(--typogrphy-display-dl-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dl-regular-font-style)]">
              On Step Away
            </h1>
            <p className="relative w-fit [font-family:'Urbanist-Medium',Helvetica] font-medium text-[#667085] text-sm tracking-[0.07px] leading-[19.6px] whitespace-nowrap">
              We sent a code to {"{user email}"}. Enter it to continue.
            </p>
          </div>
        </div>
        <fieldset
          className="flex items-center justify-center gap-3 self-stretch w-full relative flex-[0_0_auto] border-0 p-0 m-0"
          aria-label="Verification code"
        >
          {code.map((digit, index) => (
            <input
              key={`code-digit-${index}`}
              ref={(element) => {
                inputRefs.current[index] = element;
              }}
              className={`inline-flex items-center justify-center gap-2.5 px-5 py-2.5 relative self-stretch flex-[0_0_auto] w-[78px] text-center bg-neutralwhite-pure rounded-xl ${
                index === 0
                  ? "border-[1.2px] border-solid border-primarypr-5 shadow-[0px_0px_0px_2px_#3c57f633]"
                  : "border border-solid border-neutralnt-2"
              } ${
                digit ? "text-neutralnt-10" : "text-neutralnt-4"
              } font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)]`}
              aria-label={`Verification code digit ${index + 1}`}
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={1}
              value={digit}
              onChange={(event) => updateCode(index, event.target.value)}
              onKeyDown={(event) => handleKeyDown(event, index)}
              onPaste={(event) => handlePaste(event, index)}
              autoComplete={index === 0 ? "one-time-code" : "off"}
            />
          ))}
        </fieldset>
        <div className="flex flex-col items-center gap-3 self-stretch w-full relative flex-[0_0_auto]">
          <button
            className="all-unset box-border flex items-center justify-center gap-2.5 p-3 relative self-stretch w-full flex-[0_0_auto] bg-primarypr-5 rounded-xl cursor-pointer focus-visible:ring-2 focus-visible:ring-primarypr-5 focus-visible:ring-offset-2"
            type="submit"
          >
            <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Submit
            </span>
          </button>
          <p className="relative w-[269px] h-[22px] [font-family:'Urbanist-Regular',Helvetica] font-normal text-transparent text-sm text-center tracking-[0] leading-[22.4px] whitespace-nowrap">
            <span className="text-[#6a7a95] font-typogrphy-body-text-ts-regular [font-style:var(--typogrphy-body-text-ts-regular-font-style)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)]">
              Didn&apos;t receive a code?
            </span>
            <span className="text-[#3c57f6] font-typogrphy-body-text-ts-regular [font-style:var(--typogrphy-body-text-ts-regular-font-style)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)]">
              &nbsp;
            </span>
            <button
              className="font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-[#3c57f6] [font-style:var(--typogrphy-body-text-ts-medium-font-style)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)] text-[length:var(--typogrphy-body-text-ts-medium-font-size)] cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primarypr-5"
              type="button"
              onClick={() => {
                setCode(["", "", "", "", ""]);
                setMessage("");
                focusInput(0);
              }}
            >
              Send a new code
            </button>
          </p>
          <p
            className="min-h-[20px] text-center font-typogrphy-body-text-ts-regular text-sm text-neutralnt-6"
            role="status"
            aria-live="polite"
          >
            {message}
          </p>
        </div>
      </form>
    </main>
  );
};