import { FormEvent, useState } from "react";
import { Frame } from "./Frame";
import image from "./image.svg";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

export const LogoAndText = (): JSX.Element => {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="flex min-h-screen w-full items-center justify-center bg-neutralwhite-pure">
      <section
        aria-labelledby="forgot-password-title"
        className="flex w-[650px] flex-col items-center gap-[30px] rounded-3xl bg-neutralwhite-pure px-[60px] py-[50px] relative"
      >
        <div className="flex w-full flex-[0_0_auto] flex-col items-start gap-5 relative">
          <div className="flex w-full flex-[0_0_auto] items-center gap-2 relative">
            <div aria-hidden="true" className="relative h-10 w-[39.86px]">
              <img
                alt=""
                className="absolute left-0 top-0 h-full w-full"
                src={vector}
              />
              <img
                alt=""
                className="absolute left-[64.85%] top-[55.55%] h-[44.45%] w-[35.15%]"
                src={image}
              />
              <img
                alt=""
                className="absolute left-[55.52%] top-[65.09%] h-[34.91%] w-[44.48%]"
                src={vector2}
              />
              <img
                alt=""
                className="absolute left-[37.37%] top-[70.48%] h-[29.52%] w-[62.63%]"
                src={vector3}
              />
              <img
                alt=""
                className="absolute left-[15.39%] top-[64.92%] h-[35.08%] w-[84.61%]"
                src={vector4}
              />
              <img
                alt=""
                className="absolute left-[2.67%] top-[55.53%] h-[44.47%] w-[97.33%]"
                src={vector5}
              />
            </div>
            <div className="relative w-fit whitespace-nowrap font-typogrphy-display-dxs-bold text-[length:var(--typogrphy-display-dxs-bold-font-size)] font-[number:var(--typogrphy-display-dxs-bold-font-weight)] leading-[var(--typogrphy-display-dxs-bold-line-height)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] text-neutralnt-10 [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
              CourseHub
            </div>
          </div>
          <div className="flex w-full flex-[0_0_auto] flex-col items-start gap-2 relative">
            <h1
              id="forgot-password-title"
              className="relative mt-[-1px] w-fit whitespace-nowrap text-center font-typogrphy-display-dl-regular text-[length:var(--typogrphy-display-dl-regular-font-size)] font-[number:var(--typogrphy-display-dl-regular-font-weight)] leading-[var(--typogrphy-display-dl-regular-line-height)] tracking-[var(--typogrphy-display-dl-regular-letter-spacing)] text-neutralnt-10 [font-style:var(--typogrphy-display-dl-regular-font-style)]"
            >
              Forget Password?
            </h1>
            <p className="relative w-full font-typogrphy-body-text-ts-regular text-[length:var(--typogrphy-body-text-ts-regular-font-size)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] text-neutralnt-6 [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
              Forgot it? Just enter your email and we&apos;ll guide you back
              with a reset link.
            </p>
          </div>
        </div>
        <form
          aria-describedby={submitted ? "reset-status" : undefined}
          className="flex w-full flex-[0_0_auto] flex-col items-center gap-[22px] relative"
          onSubmit={handleSubmit}
        >
          <div className="flex w-full flex-[0_0_auto] flex-col items-start gap-2 relative">
            <label
              className="relative mt-[-1px] font-typogrphy-body-text-tm-semibold text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] text-neutralnt-8 [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
              htmlFor="email"
            >
              Email
            </label>
            <div className="flex w-full flex-[0_0_auto] items-center justify-between rounded-xl border border-solid border-neutralnt-2 bg-neutralwhite-pure p-3.5 relative">
              <input
                aria-invalid={submitted && email.trim() === ""}
                autoComplete="email"
                className="relative min-w-0 flex-1 font-typogrphy-body-text-ts-regular text-[length:var(--typogrphy-body-text-ts-regular-font-size)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] text-neutralnt-8 placeholder:text-neutralnt-4 [font-style:var(--typogrphy-body-text-ts-regular-font-style)]"
                id="email"
                name="email"
                onChange={(event) => {
                  setEmail(event.target.value);
                  setSubmitted(false);
                }}
                placeholder="your@mail.com"
                required
                type="email"
                value={email}
              />
              <Frame
                aria-hidden="true"
                className="!relative !h-4 !w-4 !aspect-[1] shrink-0"
              />
            </div>
          </div>
          <button
            className="all-unset box-border flex w-full flex-[0_0_auto] items-center justify-center gap-2.5 rounded-xl bg-primarypr-5 p-3 relative text-center"
            type="submit"
          >
            <span className="relative mt-[-1px] w-fit whitespace-nowrap font-typogrphy-body-text-tm-medium text-[length:var(--typogrphy-body-text-tm-medium-font-size)] font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] text-neutralwhite-pure [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
              Submit
            </span>
          </button>
          <a
            className="flex w-full flex-[0_0_auto] items-center justify-center gap-2.5 rounded-lg bg-primarypr-1 px-3.5 py-3 relative text-center"
            href="/login"
          >
            <span className="relative mt-[-1px] w-fit whitespace-nowrap font-typogrphy-body-text-tm-regular text-[length:var(--typogrphy-body-text-tm-regular-font-size)] font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] text-primarypr-5 [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
              Back to Login
            </span>
          </a>
          <p aria-live="polite" className="sr-only" id="reset-status">
            {submitted
              ? "If an account exists for this email, a reset link will be sent."
              : ""}
          </p>
        </form>
      </section>
    </main>
  );
};