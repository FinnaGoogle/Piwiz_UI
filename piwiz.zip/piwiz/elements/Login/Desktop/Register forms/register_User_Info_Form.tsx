import { ChangeEvent, FormEvent, useRef, useState } from "react";

type GoalOption = {
  value: string;
  label: string;
};

const goalOptions: GoalOption[] = [
  { value: "", label: "Select skills" },
  { value: "design", label: "Improve design skills" },
  { value: "development", label: "Improve development skills" },
  { value: "marketing", label: "Improve marketing skills" },
  { value: "business", label: "Grow my business" },
];

const acceptedFileTypes = ["image/jpeg", "image/png"];
const maxFileSize = 1024 * 1024;

const UserAvatar = (): JSX.Element => {
  return (
    <svg
      aria-hidden="true"
      className="h-[26px] w-[26px]"
      fill="none"
      viewBox="0 0 26 26"
    >
      <circle
        cx="13"
        cy="7.5"
        r="5.5"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.8"
      />
      <path
        d="M3.5 22.25C3.5 18.66 6.41 15.75 10 15.75H16C19.59 15.75 22.5 18.66 22.5 22.25V22.25C22.5 22.94 21.94 23.5 21.25 23.5H4.75C4.06 23.5 3.5 22.94 3.5 22.25V22.25Z"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.8"
      />
    </svg>
  );
};

const HelperIcon = (): JSX.Element => {
  return (
    <svg
      aria-hidden="true"
      className="h-3.5 w-3.5 shrink-0"
      fill="none"
      viewBox="0 0 14 14"
    >
      <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.5" />
      <path
        d="M7 6.25V10"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.5"
      />
      <circle cx="7" cy="4.25" r="0.75" fill="currentColor" />
    </svg>
  );
};

const ChevronDown = (): JSX.Element => {
  return (
    <svg
      aria-hidden="true"
      className="h-4 w-4 shrink-0"
      fill="none"
      viewBox="0 0 16 16"
    >
      <path
        d="M3 6L8 11L13 6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
    </svg>
  );
};

export const UserInfoContainer = (): JSX.Element => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState("");
  const [selectedGoal, setSelectedGoal] = useState("");
  const [fileError, setFileError] = useState("");

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0];

    if (!file) {
      setFileName("");
      setFileError("");
      return;
    }

    if (!acceptedFileTypes.includes(file.type)) {
      setFileName("");
      setFileError("Please choose a JPG, JPEG, or PNG image.");
      event.target.value = "";
      return;
    }

    if (file.size > maxFileSize) {
      setFileName("");
      setFileError("The selected image must be smaller than 1 MB.");
      event.target.value = "";
      return;
    }

    setFileError("");
    setFileName(file.name);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
  };

  const handleSkip = (): void => {
    setFileError("");
  };

  return (
    <main className="flex flex-col items-center gap-[30px] px-[60px] py-[50px] relative bg-neutralwhite-pure rounded-3xl">
      <header className="flex flex-col items-center gap-1.5 relative self-stretch w-full flex-[0_0_auto]">
        <div
          aria-label="User avatar"
          className="inline-flex items-center gap-2.5 p-6 relative flex-[0_0_auto] bg-neutralnt-1 rounded-[90px] text-primarypr-5"
        >
          <UserAvatar />
        </div>
        <div className="flex flex-col items-center gap-0.5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] text-neutralnt-9 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] text-center tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
            {"{Display Name of User}"}
          </div>
          <div className="relative self-stretch font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] text-center tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] [font-style:var(--typogrphy-body-text-txs-regular-font-style)]">
            {"{user email}"}
          </div>
        </div>
      </header>
      <form
        aria-label="Complete your profile"
        className="flex flex-col items-center gap-[22px] w-full flex-[0_0_auto] relative self-stretch"
        onSubmit={handleSubmit}
      >
        <div className="flex flex-col items-start gap-5 w-full flex-[0_0_auto] relative self-stretch">
          <div className="flex flex-col w-[530px] max-w-full items-start gap-2 relative flex-[0_0_auto]">
            <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
              <label
                className="mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] relative self-stretch [font-style:var(--typogrphy-body-text-tm-medium-font-style)]"
                htmlFor="avatar-upload"
              >
                Upload Your Avatar
              </label>
              <div className="flex h-[50px] items-center justify-between p-3.5 w-full bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 relative self-stretch">
                <span
                  className={`relative min-w-0 overflow-hidden text-ellipsis whitespace-nowrap mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)] ${
                    fileName ? "text-neutralnt-8" : "text-neutralnt-4"
                  }`}
                >
                  {fileName || "Browse your image..."}
                </span>
                <label
                  className="inline-flex cursor-pointer items-center justify-center gap-2.5 px-2.5 py-1 relative flex-[0_0_auto] mt-[-4.00px] mb-[-4.00px] bg-primarypr-5 rounded-lg"
                  htmlFor="avatar-upload"
                >
                  <span className="text-neutralwhite-pure relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
                    Choose File
                  </span>
                </label>
                <input
                  ref={fileInputRef}
                  accept=".jpg,.jpeg,.png,image/jpeg,image/png"
                  className="sr-only"
                  id="avatar-upload"
                  name="avatar"
                  onChange={handleFileChange}
                  type="file"
                />
              </div>
            </div>
            <div
              aria-live="polite"
              className="flex items-center gap-1.5 relative self-stretch w-full flex-[0_0_auto]"
            >
              <span className="text-neutralnt-6">
                <HelperIcon />
              </span>
              <p className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-txs-regular-font-style)]">
                {fileError ||
                  "Only JPG, JPEG or PNG files with max size of 1 MB."}
              </p>
            </div>
          </div>
          <div className="flex flex-col items-start gap-2 w-full flex-[0_0_auto] relative self-stretch">
            <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
              <label
                className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
                htmlFor="goal"
              >
                Choose Your Goal
              </label>
              <div className="relative self-stretch w-full flex-[0_0_auto]">
                <select
                  aria-label="Choose your goal"
                  className={`flex h-auto w-full cursor-pointer items-center justify-between p-3.5 pr-12 relative bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)] ${
                    selectedGoal ? "text-neutralnt-8" : "text-neutralnt-4"
                  }`}
                  id="goal"
                  name="goal"
                  onChange={(event) => setSelectedGoal(event.target.value)}
                  value={selectedGoal}
                >
                  {goalOptions.map((option) => (
                    <option
                      key={option.value || "placeholder"}
                      value={option.value}
                    >
                      {option.label}
                    </option>
                  ))}
                </select>
                <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-neutralnt-5">
                  <ChevronDown />
                </span>
              </div>
            </div>
          </div>
        </div>
        <button
          className="all-unset box-border flex cursor-pointer items-center justify-center gap-2.5 p-3 relative self-stretch w-full flex-[0_0_auto] bg-primarypr-5 rounded-xl"
          type="submit"
        >
          <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
            Continue
          </span>
        </button>
      </form>
      <button
        className="flex cursor-pointer items-center justify-center gap-2.5 px-3.5 py-3 relative self-stretch w-full flex-[0_0_auto] bg-primarypr-1 rounded-lg"
        onClick={handleSkip}
        type="button"
      >
        <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] text-primarypr-5 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
          Skip for Now
        </span>
      </button>
    </main>
  );
};
