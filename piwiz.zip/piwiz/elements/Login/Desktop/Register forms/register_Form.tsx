import { FormEvent, useState } from "react";
import { Frame } from "./Frame";
import { Frame1 } from "./Frame1";
import { GoogleButtonIcon } from "./GoogleButtonIcon";
import { IconComponentNode } from "./IconComponentNode";
import line10 from "./line-10.svg";
import line11 from "./line-11.svg";

type FormValues = {
  name: string;
  email: string;
  password: string;
};

const fields = [
  {
    id: "name",
    label: "Your Name",
    placeholder: "Enter your full name",
    type: "text",
    autoComplete: "name",
  },
  {
    id: "email",
    label: "Email",
    placeholder: "your@mail.com",
    type: "email",
    autoComplete: "email",
  },
] as const;

export const FormContainer = (): JSX.Element => {
  const [values, setValues] = useState<FormValues>({
    name: "",
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (field: keyof FormValues, value: string) => {
    setValues((currentValues) => ({
      ...currentValues,
      [field]: value,
    }));
    setSubmitted(false);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);

    if (
      values.name.trim() &&
      values.email.trim() &&
      values.password.length >= 8
    ) {
      setSubmitted(false);
    }
  };

  const isPasswordValid =
    values.password.length === 0 || values.password.length >= 8;

  return (
    <form
      className="flex flex-col items-center gap-[22px] relative"
      onSubmit={handleSubmit}
      noValidate
    >
      <div className="flex-col items-start gap-5 flex relative self-stretch w-full flex-[0_0_auto]">
        {fields.map((field) => (
          <div
            className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]"
            key={field.id}
          >
            <label
              className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
              htmlFor={field.id}
            >
              {field.label}
            </label>
            <div className="flex items-center gap-2.5 p-3.5 relative self-stretch w-full flex-[0_0_auto] bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2">
              <input
                id={field.id}
                name={field.id}
                className="relative w-full mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-4 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)] [background:transparent] border-[none] p-0"
                placeholder={field.placeholder}
                type={field.type}
                autoComplete={field.autoComplete}
                value={values[field.id]}
                onChange={(event) => handleChange(field.id, event.target.value)}
                aria-invalid={submitted && !values[field.id] ? "true" : "false"}
                required
              />
              {field.id === "email" && (
                <Frame
                  className="!relative !w-4 !h-4 !aspect-[1]"
                  aria-hidden="true"
                />
              )}
            </div>
          </div>
        ))}

        <div className="flex-col items-start gap-2 flex relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <label
              className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
              htmlFor="password"
            >
              Password
            </label>
            <div className="items-center justify-between p-3.5 bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 flex relative self-stretch w-full flex-[0_0_auto]">
              <input
                id="password"
                name="password"
                className="relative w-full mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-4 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)] [background:transparent] border-[none] p-0"
                placeholder="**************"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                value={values.password}
                onChange={(event) =>
                  handleChange("password", event.target.value)
                }
                aria-invalid={
                  !isPasswordValid || (submitted && !values.password)
                    ? "true"
                    : "false"
                }
                aria-describedby="password-hint"
                required
                minLength={8}
              />
              <button
                className="flex shrink-0 items-center justify-center"
                type="button"
                onClick={() => setShowPassword((visible) => !visible)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                aria-pressed={showPassword}
              >
                <IconComponentNode
                  className="!relative !w-4 !h-4 !aspect-[1]"
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-1.5 relative self-stretch w-full flex-[0_0_auto]">
            <Frame1
              className="!relative !w-3.5 !h-3.5 !aspect-[1]"
              aria-hidden="true"
            />
            <p
              id="password-hint"
              className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-txs-regular font-[number:var(--typogrphy-body-text-txs-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-txs-regular-font-size)] tracking-[var(--typogrphy-body-text-txs-regular-letter-spacing)] leading-[var(--typogrphy-body-text-txs-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-txs-regular-font-style)]"
            >
              Use at least 8 characters with a mix of letters and numbers.
            </p>
          </div>
        </div>
      </div>
      <button
        className="all-unset box-border gap-2.5 bg-primarypr-5 flex items-center justify-center p-3 relative self-stretch w-full flex-[0_0_auto] rounded-xl"
        type="submit"
      >
        <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
          Sign up
        </span>
      </button>
      <div className="flex items-center justify-center gap-2 relative self-stretch w-full flex-[0_0_auto]">
        <img
          className="relative flex-1 grow h-px object-cover"
          alt=""
          src={line10}
          aria-hidden="true"
        />
        <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-6 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] text-center tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
          or sign up with
        </span>
        <img
          className="relative flex-1 grow h-px object-cover"
          alt=""
          src={line11}
          aria-hidden="true"
        />
      </div>
      <button
        className="gap-3 border border-solid border-neutralnt-4 flex items-center justify-center p-3 relative self-stretch w-full flex-[0_0_auto] rounded-xl"
        type="button"
        onClick={() => setSubmitted(false)}
      >
        <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] text-neutralnt-9 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
          Sign up with Google
        </span>
        <GoogleButtonIcon
          className="!relative !w-5 !h-5 !aspect-[0.99]"
          aria-hidden="true"
        />
      </button>
      <p className="relative self-stretch [font-family:'Urbanist-Regular',Helvetica] font-normal text-transparent text-sm text-center tracking-[0] leading-[22.4px]">
        <span className="text-[#6a7a95] font-typogrphy-body-text-ts-regular [font-style:var(--typogrphy-body-text-ts-regular-font-style)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)]">
          Already have an account?{" "}
        </span>
        <button
          className="font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-[#3c57f6] [font-style:var(--typogrphy-body-text-ts-medium-font-style)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)] text-[length:var(--typogrphy-body-text-ts-medium-font-size)]"
          type="button"
        >
          Register
        </button>
      </p>
    </form>
  );
};
