import { FormEvent, useState } from "react";
import { Frame } from "./Frame";
import { GoogleIconColour } from "./GoogleIconColour";
import { IconComponentNode } from "./IconComponentNode";
import line10 from "./line-10.svg";
import line11 from "./line-11.svg";

export const Container = (): JSX.Element => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <form
      className="flex flex-col items-center gap-[22px] relative"
      onSubmit={handleSubmit}
      noValidate
    >
      <div className="flex-col items-start gap-5 flex relative self-stretch w-full flex-[0_0_auto]">
        <div className="flex-col items-start gap-2 flex relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <label
              htmlFor="email"
              className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
            >
              Email
            </label>
            <div className="items-center justify-between p-3.5 bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 flex relative self-stretch w-full flex-[0_0_auto]">
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => {
                  setEmail(event.target.value);
                  setSubmitted(false);
                }}
                placeholder="your@mail.com"
                aria-invalid={submitted && !email ? "true" : "false"}
                className="relative min-w-0 flex-1 mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-4 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)] placeholder:text-neutralnt-4"
              />
              <Frame
                className="!relative !w-4 !h-4 !aspect-[1] shrink-0"
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
        <div className="flex-col items-end gap-3 flex relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex-col items-start gap-2 flex relative self-stretch w-full flex-[0_0_auto]">
            <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
              <label
                htmlFor="password"
                className="relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-semibold font-[number:var(--typogrphy-body-text-tm-semibold-font-weight)] text-neutralnt-8 text-[length:var(--typogrphy-body-text-tm-semibold-font-size)] tracking-[var(--typogrphy-body-text-tm-semibold-letter-spacing)] leading-[var(--typogrphy-body-text-tm-semibold-line-height)] [font-style:var(--typogrphy-body-text-tm-semibold-font-style)]"
              >
                Password
              </label>
              <div className="items-center justify-between p-3.5 bg-neutralwhite-pure rounded-xl border border-solid border-neutralnt-2 flex relative self-stretch w-full flex-[0_0_auto]">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(event) => {
                    setPassword(event.target.value);
                    setSubmitted(false);
                  }}
                  placeholder="**************"
                  aria-invalid={submitted && !password ? "true" : "false"}
                  className="relative min-w-0 flex-1 mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-4 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)] placeholder:text-neutralnt-4"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((visible) => !visible)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="flex shrink-0 items-center justify-center cursor-pointer"
                >
                  <IconComponentNode
                    className="!relative !w-4 !h-4 !aspect-[1]"
                    aria-hidden="true"
                  />
                </button>
              </div>
            </div>
          </div>
          <button
            type="button"
            className="relative w-fit font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-primarypr-5 text-[length:var(--typogrphy-body-text-ts-medium-font-size)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-medium-font-style)] cursor-pointer"
            onClick={() => undefined}
          >
            Forgot Your Password?
          </button>
        </div>
      </div>
      <button
        type="submit"
        className="gap-2.5 bg-primarypr-5 flex items-center justify-center p-3 relative self-stretch w-full flex-[0_0_auto] rounded-xl cursor-pointer"
      >
        <span className="relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralwhite-pure text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-medium-font-style)]">
          Sign in
        </span>
      </button>
      <div
        className="items-center justify-center gap-2 flex relative self-stretch w-full flex-[0_0_auto]"
        aria-hidden="true"
      >
        <img
          className="relative flex-1 grow h-px object-cover"
          alt=""
          src={line10}
        />
        <span className="text-neutralnt-6 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] text-center leading-[var(--typogrphy-body-text-ts-regular-line-height)] relative w-fit mt-[-1.00px] font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] whitespace-nowrap [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
          or sign in with
        </span>
        <img
          className="relative flex-1 grow h-px object-cover"
          alt=""
          src={line11}
        />
      </div>
      <button
        type="button"
        className="gap-3 border border-solid border-neutralnt-4 flex items-center justify-center p-3 relative self-stretch w-full flex-[0_0_auto] rounded-xl cursor-pointer"
        onClick={() => undefined}
      >
        <span className="text-neutralnt-9 text-[length:var(--typogrphy-body-text-tm-regular-font-size)] leading-[var(--typogrphy-body-text-tm-regular-line-height)] relative w-fit mt-[-1.00px] font-typogrphy-body-text-tm-regular font-[number:var(--typogrphy-body-text-tm-regular-font-weight)] tracking-[var(--typogrphy-body-text-tm-regular-letter-spacing)] whitespace-nowrap [font-style:var(--typogrphy-body-text-tm-regular-font-style)]">
          Sign in with Google
        </span>
        <GoogleIconColour
          className="!relative !w-5 !h-5 !aspect-[0.99]"
          aria-hidden="true"
        />
      </button>
      <p className="relative self-stretch [font-family:'Urbanist-Regular',Helvetica] font-normal text-transparent text-sm text-center tracking-[0] leading-[22.4px]">
        <span className="text-[#6a7a95] font-typogrphy-body-text-ts-regular [font-style:var(--typogrphy-body-text-ts-regular-font-style)] font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] text-[length:var(--typogrphy-body-text-ts-regular-font-size)]">
          Don&apos;t have an account yet?{" "}
        </span>
        <button
          type="button"
          className="font-typogrphy-body-text-ts-medium font-[number:var(--typogrphy-body-text-ts-medium-font-weight)] text-[#3c57f6] [font-style:var(--typogrphy-body-text-ts-medium-font-style)] tracking-[var(--typogrphy-body-text-ts-medium-letter-spacing)] leading-[var(--typogrphy-body-text-ts-medium-line-height)] text-[length:var(--typogrphy-body-text-ts-medium-font-size)] cursor-pointer"
          onClick={() => undefined}
        >
          Register
        </button>
      </p>
    </form>
  );
};

export default Container;
