D:\projects\piwiz\elements\Navbarimport { IconComponentNode } from "./IconComponentNode";
import image from "./image.svg";
import { SocialMediaIcon } from "./SocialMediaIcon";
import { SocialMediaIcon1 } from "./SocialMediaIcon1";
import { SocialMediaIcon2 } from "./SocialMediaIcon2";
import vector from "./vector.svg";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";

const navigationColumns = [
  {
    title: "Navigate",
    links: ["Categories", "Courses", "Deals", "New", "Certificates"],
  },
  {
    title: "Company",
    links: ["About Us", "News", "Sell Courses", "Mentor", "Blog"],
  },
  {
    title: "Support",
    links: [
      "Security",
      "Terms & Conditions",
      "Career",
      "Comments",
      "Community",
    ],
  },
];

const socialLinks = [
  {
    label: "Instagram",
    icon: SocialMediaIcon,
  },
  {
    label: "YouTube",
    icon: IconComponentNode,
  },
  {
    label: "Dribbble",
    icon: SocialMediaIcon1,
  },
  {
    label: "X",
    icon: SocialMediaIcon2,
  },
];

const typographyRegular =
  "relative self-stretch font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-1 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)]";

const typographyMedium =
  "relative self-stretch mt-[-1.00px] font-typogrphy-body-text-tm-medium font-[number:var(--typogrphy-body-text-tm-medium-font-weight)] text-neutralnt-1 text-[length:var(--typogrphy-body-text-tm-medium-font-size)] tracking-[var(--typogrphy-body-text-tm-medium-letter-spacing)] leading-[var(--typogrphy-body-text-tm-medium-line-height)] [font-style:var(--typogrphy-body-text-tm-medium-font-style)]";

export const MainContainer = (): JSX.Element => {
  return (
    <footer className="inline-flex items-start gap-[505px] p-[60px] relative bg-primarypr-9">
      <div className="flex flex-col w-[315px] items-start gap-[30px] relative">
        <div className="flex flex-col items-start gap-5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="inline-flex items-center gap-2 relative flex-[0_0_auto]">
            <div className="relative w-[39.86px] h-10" aria-hidden="true">
              <img
                className="absolute w-full h-full top-0 left-0"
                alt=""
                src={vector}
              />
              <img
                className="absolute w-[35.15%] h-[44.45%] top-[55.55%] left-[64.85%]"
                alt=""
                src={image}
              />
              <img
                className="absolute w-[44.48%] h-[34.91%] top-[65.09%] left-[55.52%]"
                alt=""
                src={vector2}
              />
              <img
                className="absolute w-[62.63%] h-[29.52%] top-[70.48%] left-[37.37%]"
                alt=""
                src={vector3}
              />
              <img
                className="absolute w-[84.61%] h-[35.08%] top-[64.92%] left-[15.39%]"
                alt=""
                src={vector4}
              />
              <img
                className="absolute w-[97.33%] h-[44.47%] top-[55.53%] left-[2.67%]"
                alt=""
                src={vector5}
              />
            </div>
            <div className="relative w-fit font-typogrphy-display-dxs-bold font-[number:var(--typogrphy-display-dxs-bold-font-weight)] text-neutralnt-1 text-[length:var(--typogrphy-display-dxs-bold-font-size)] tracking-[var(--typogrphy-display-dxs-bold-letter-spacing)] leading-[var(--typogrphy-display-dxs-bold-line-height)] whitespace-nowrap [font-style:var(--typogrphy-display-dxs-bold-font-style)]">
              CourseHub
            </div>
          </div>
          <p className="relative self-stretch font-typogrphy-body-text-ts-regular font-[number:var(--typogrphy-body-text-ts-regular-font-weight)] text-neutralnt-1 text-[length:var(--typogrphy-body-text-ts-regular-font-size)] tracking-[var(--typogrphy-body-text-ts-regular-letter-spacing)] leading-[var(--typogrphy-body-text-ts-regular-line-height)] [font-style:var(--typogrphy-body-text-ts-regular-font-style)]">
            CourseHub is an e-learning platform with expert-led courses.
            Learning made simple, practical, and accessible.
          </p>
        </div>
        <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
          <h2 className={typographyMedium}>Follow Us</h2>
          <div
            className="flex items-center gap-2.5 relative self-stretch w-full flex-[0_0_auto]"
            aria-label="Social media links"
          >
            {socialLinks.map(({ label, icon: Icon }) => (
              <a
                key={label}
                href="#"
                aria-label={label}
                className="flex w-11 h-11 items-center justify-center gap-2.5 px-1.5 py-2 relative bg-primarypr-9 rounded-xl border border-solid border-neutralnt-1 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutralnt-1"
              >
                <Icon className="!relative !w-5 !h-5 !aspect-[1]" />
              </a>
            ))}
          </div>
        </div>
      </div>
      <nav
        className="inline-flex items-center gap-10 relative flex-[0_0_auto]"
        aria-label="Footer navigation"
      >
        {navigationColumns.map((column) => (
          <section
            key={column.title}
            className="flex flex-col w-[140px] items-start gap-4 relative"
            aria-labelledby={`${column.title.toLowerCase()}-heading`}
          >
            <h2
              id={`${column.title.toLowerCase()}-heading`}
              className={typographyMedium}
            >
              {column.title}
            </h2>
            <ul className="flex flex-col items-start gap-3 relative self-stretch w-full flex-[0_0_auto]">
              {column.links.map((link, index) => (
                <li
                  key={`${column.title}-${link}`}
                  className={`${typographyRegular}${index === 0 ? " mt-[-1.00px]" : ""}`}
                >
                  <a
                    href="#"
                    className="focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutralnt-1"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </nav>
    </footer>
  );
};